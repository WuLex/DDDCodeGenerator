using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Repository;
using BBS.Domain.Interfaces.Service;
using BBS.Domain.Services.Common;

namespace BBS.Domain.Services
{
    public class BBSService : ServiceBase<BBS>, IBBSService
    {
        private readonly ISubjectRepository _subjectRepository;
        public AnexoService(ISubjectRepository subjectRepository) : base(subjectRepository)
        {
            _subjectRepository = subjectRepository;
        }
    }
}