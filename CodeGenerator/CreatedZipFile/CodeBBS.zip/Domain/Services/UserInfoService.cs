using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Repository;
using BBS.Domain.Interfaces.Service;
using BBS.Domain.Services.Common;

namespace BBS.Domain.Services
{
    public class BBSService : ServiceBase<BBS>, IBBSService
    {
        private readonly IUserinfoRepository _userinfoRepository;
        public AnexoService(IUserinfoRepository userinfoRepository) : base(userinfoRepository)
        {
            _userinfoRepository = userinfoRepository;
        }
    }
}