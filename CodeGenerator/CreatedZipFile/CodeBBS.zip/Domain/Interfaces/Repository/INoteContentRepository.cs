using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Repository.Common;

namespace BBS.Domain.Interfaces.Repository
{
    public interface INotecontentRepository : IRepositoryBase<Notecontent>
    {
    }
}
