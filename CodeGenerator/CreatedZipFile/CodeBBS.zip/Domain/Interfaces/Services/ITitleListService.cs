using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Service.Common;

namespace BBS.Domain.Interfaces.Service
{
    public interface ITitlelistService : IServiceBase<Titlelist>
    {
    }
}