using BBS.Application.Interfaces.Common;
using BBS.Application.ViewModels;

namespace BBS.Application.Interfaces
{
    public interface ISubjectAppService : IAppServicesBase<SubjectViewModel>
    {
    }
}
