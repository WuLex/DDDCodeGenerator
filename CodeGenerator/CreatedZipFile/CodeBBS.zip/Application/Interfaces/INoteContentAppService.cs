using BBS.Application.Interfaces.Common;
using BBS.Application.ViewModels;

namespace BBS.Application.Interfaces
{
    public interface INotecontentAppService : IAppServicesBase<NotecontentViewModel>
    {
    }
}
