using BBS.Application.Interfaces.Common;
using BBS.Application.ViewModels;

namespace BBS.Application.Interfaces
{
    public interface IUserinfoAppService : IAppServicesBase<UserinfoViewModel>
    {
    }
}
