using AutoMapper;
using BBS.Application.Interfaces;
using BBS.Application.Services.Common;
using BBS.Application.ViewModels;
using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Service;

namespace BBS.Application.Services
{
    public class BallotAppService : ServiceBase<BallotViewModel, Ballot>, IBallotAppService
    {
        private readonly IMapper _mapper;
        private readonly IBallotService _ballotService;
        public BallotAppService(IMapper mapper, IBallotService ballotService) : base(mapper, ballotService)
        {
            _mapper = mapper;
            _ballotService = ballotService;
        }
    }
}