using AutoMapper;
using BBS.Application.Interfaces;
using BBS.Application.Services.Common;
using BBS.Application.ViewModels;
using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Service;

namespace BBS.Application.Services
{
    public class UserinfoAppService : ServiceBase<UserinfoViewModel, Userinfo>, IUserinfoAppService
    {
        private readonly IMapper _mapper;
        private readonly IUserinfoService _userinfoService;
        public UserinfoAppService(IMapper mapper, IUserinfoService userinfoService) : base(mapper, userinfoService)
        {
            _mapper = mapper;
            _userinfoService = userinfoService;
        }
    }
}