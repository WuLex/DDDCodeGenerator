using AutoMapper;
using BBS.Application.Interfaces;
using BBS.Application.Services.Common;
using BBS.Application.ViewModels;
using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Service;

namespace BBS.Application.Services
{
    public class NotecontentAppService : ServiceBase<NotecontentViewModel, Notecontent>, INotecontentAppService
    {
        private readonly IMapper _mapper;
        private readonly INotecontentService _notecontentService;
        public NotecontentAppService(IMapper mapper, INotecontentService notecontentService) : base(mapper, notecontentService)
        {
            _mapper = mapper;
            _notecontentService = notecontentService;
        }
    }
}