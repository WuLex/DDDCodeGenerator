using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Repository;

namespace BBS.Infra.Data.Repository
{
    public class NotecontentRepository : RepositoryBase<Notecontent>, INotecontentRepository
    {
        private readonly ApplicationDbContext _context;
        public NotecontentRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }
    }
}
