using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Repository;

namespace BBS.Infra.Data.Repository
{
    public class TitlelistRepository : RepositoryBase<Titlelist>, ITitlelistRepository
    {
        private readonly ApplicationDbContext _context;
        public TitlelistRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }
    }
}
