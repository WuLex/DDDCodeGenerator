using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Repository;

namespace BBS.Infra.Data.Repository
{
    public class UserinfoRepository : RepositoryBase<Userinfo>, IUserinfoRepository
    {
        private readonly ApplicationDbContext _context;
        public UserinfoRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }
    }
}
