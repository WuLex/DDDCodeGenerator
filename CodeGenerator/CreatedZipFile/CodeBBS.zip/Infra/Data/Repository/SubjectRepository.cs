using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Repository;

namespace BBS.Infra.Data.Repository
{
    public class SubjectRepository : RepositoryBase<Subject>, ISubjectRepository
    {
        private readonly ApplicationDbContext _context;
        public SubjectRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }
    }
}
