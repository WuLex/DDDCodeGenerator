using BBS.Domain.Entities;
using BBS.Domain.Interfaces.Repository;

namespace BBS.Infra.Data.Repository
{
    public class BallotRepository : RepositoryBase<Ballot>, IBallotRepository
    {
        private readonly ApplicationDbContext _context;
        public BallotRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }
    }
}
