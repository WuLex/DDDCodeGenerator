using BBS.Application.Interfaces;
using BBS.Application.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace BBS.Api.Controllers
{
    [Route("api/[controller]/")]
    [ApiController]
    public class UserinfoController : BaseController<UserinfoViewModel>
    {
        private readonly IUserinfoServiceAppService _userinfoAppService;
        public UserinfoController(IUserinfoAppService userinfoAppService) : base(userinfoAppService)
        {
            _userinfoAppService = UserinfoAppService;
        }
    }
}