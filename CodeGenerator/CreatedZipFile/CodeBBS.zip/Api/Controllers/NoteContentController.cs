using BBS.Application.Interfaces;
using BBS.Application.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace BBS.Api.Controllers
{
    [Route("api/[controller]/")]
    [ApiController]
    public class NotecontentController : BaseController<NotecontentViewModel>
    {
        private readonly INotecontentServiceAppService _notecontentAppService;
        public NotecontentController(INotecontentAppService notecontentAppService) : base(notecontentAppService)
        {
            _notecontentAppService = NotecontentAppService;
        }
    }
}