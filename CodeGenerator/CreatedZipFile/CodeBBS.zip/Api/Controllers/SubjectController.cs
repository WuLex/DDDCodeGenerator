using BBS.Application.Interfaces;
using BBS.Application.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace BBS.Api.Controllers
{
    [Route("api/[controller]/")]
    [ApiController]
    public class SubjectController : BaseController<SubjectViewModel>
    {
        private readonly ISubjectServiceAppService _subjectAppService;
        public SubjectController(ISubjectAppService subjectAppService) : base(subjectAppService)
        {
            _subjectAppService = SubjectAppService;
        }
    }
}