using BBS.Application.Interfaces;
using BBS.Application.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace BBS.Api.Controllers
{
    [Route("api/[controller]/")]
    [ApiController]
    public class TitlelistController : BaseController<TitlelistViewModel>
    {
        private readonly ITitlelistServiceAppService _titlelistAppService;
        public TitlelistController(ITitlelistAppService titlelistAppService) : base(titlelistAppService)
        {
            _titlelistAppService = TitlelistAppService;
        }
    }
}