using BBS.Application.Interfaces;
using BBS.Application.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace BBS.Api.Controllers
{
    [Route("api/[controller]/")]
    [ApiController]
    public class BallotController : BaseController<BallotViewModel>
    {
        private readonly IBallotServiceAppService _ballotAppService;
        public BallotController(IBallotAppService ballotAppService) : base(ballotAppService)
        {
            _ballotAppService = BallotAppService;
        }
    }
}